
/* Ud. debe completar la definicion de esta estructura en el archivo
 * reunion.c.
 */
typedef struct reunion Reunion;

/* Implemente estas funciones en reunion.c */
Reunion *nuevaReunion();
void entrar(Reunion *r);
void concluir(Reunion *r);
